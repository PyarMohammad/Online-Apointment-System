﻿$(document).ready(function () {
    BindCity();
});

function Clear() {
    $("#txtname").val("");
    $("#ddlcity").val("0");
    $("#txtphone").val("");
    $("#btnhospital").val("Hospital");
}


function HospitalDetailData() {
    $.ajax({
        url: '../HospitalDetail/Insert',
        data: { H_name: $("#txtname").val(), H_city: $("#ddlcity").val(), H_phone: $("#txtphone").val() },
        success: function () {
            alert("Hospita Data successfull insert!");
            Clear();
        },
        error: function () {
            alert("Hospital Data not insert");
        }
    });
}

function BindCity() {
    $.ajax({
        url: '../HospitalDetail/DisplayCity',
        type: 'post',
        data: {},
        async: false,
        success: function (data) {
            for (var i = 0; i < data.length; i++) {
                $("#ddlcity").append($('<option/>').attr("value", data[i].cid).text(data[i].cname));
            }
        },
        error: function () {
            alert("City not found!");
        }
    });
}