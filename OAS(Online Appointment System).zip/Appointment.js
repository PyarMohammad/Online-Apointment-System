﻿
function Clear() {
    $("#txtname").val("");
    $("#txtldept").val("");
    $("#txtappointment").val("");
    $("#txtproblem").val("");
    $("#txtphone").val("");
    $("#txtemail").val("");
    $("#btnappointment").val("Appointment");
}

function Appointment() {
    $.ajax({
        url: '../Appointment/Insert',
        data: { p_name: $("#txtname").val(), dept: $("#txtldept").val(), appointment_date: $("#txtappointment").val(), p_problem: $("#txtproblem").val(), p_phone: $("#txtphone").val(), p_email: $("#txtemail").val() },
        success: function () {
            alert("Appointment is successfull !");
            Clear();
        },
        error: function () {
            alert("Appointment faill!!");
        }
    });
}