﻿function Validation() {
    var Dabba = "";

    Dabba += checkfname();
    Dabba += checklname();
    Dabba += checkage();
    Dabba += checkaddress();
    Dabba += checkphone();
    Dabba += checkemail();
    Dabba += checkdiagnosis();
    Dabba += checkpaw();

    if (Dabba != "") {
        alert(Dabba);
        return false;
    }
    else {
        RagisterdData();
    }
}

function checkfname() {
    var TB = $("#txtfname");
    var Exp = /^[a-z A-Z]+$/
    if (TB.val() == "") {
        return "Please Enter Your Fname!!\n";
    }
    else if (!Exp.test(TB.val())) {
        return "Please Enter Only In Alphabate!!\n";
    }
    else {
        return "";
    }
}

function checklname() {
    var TB = $("#txtlname");
    var Exp = /^[a-z A-Z]+$/
    if (TB.val() == "") {
        return "Please Enter Your Lname!!\n";
    }
    else if (!Exp.test(TB.val())) {
        return "Please Enter Only In Alphabate!!\n";
    }
    else {
        return "";
    }
}

function checkage() {
    var TB = $("#txtage");
    var Exp = /^[0-9]+$/
    if (TB.val() == "") {
        return "Please Enter Your age!!\n";
    }
    else if (!Exp.test(TB.val())) {
        return "Please Enter Only In numerical!!\n";
    }
    else {
        return "";
    }
}

function checkaddress() {
    var TB = $("#txtaddress");
    if (TB.val() == "") {
        return "Please enter the address!!\n";
    }
    else {
        return "";
    }
}

function checkphone() {
    var TB = $("#txtphone");
    if (TB.val() == "") {
        return "Please enter the phone number!!\n";
    }
    else {
        return "";
    }
}


function checkemail() {
    var TB = $("#txtemail");
    var Exp = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
    if (TB.val() == "") {
        return 'Please enter your email\n'
    }
    else if (!Exp.test(TB.val())) {
        return "Please Enter valid email!!\n";
    }
    else {
        return "";
    }
}

function checkdiagnosis() {
    var TB = $("#txtdiagnosis");
    if (TB.val() == "") {
        return "Please enter Your diagnosis!!\n";
    }
    else {
        return "";
    }
}


function checkpaw() {
    var TB1 = $("#txtpwd");
    var TB2 = $("#txtconpwd");
    if (TB1.val() == "") {
        return "Please enter your password\n";
    }
    else if (TB2.val() == "") {
        return "Please enter your confirm password\n";
    }
    else if (TB1.val() != TB2.val()) {
        return "Password did not matched\n";
    }
    else {
        return "";
    }
}