﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity_OAPS.Model;

namespace Entity_OAPS.Controllers
{
    public class AppointmentController : Controller
    {
        Entity_OAPSEntities1 db = new Entity_OAPSEntities1();
        public ActionResult AppointmentIndex()
        {
            return View();
        }
        public void Insert(tblAppointment obj)
        {
            db.tblAppointments.Add(obj);
            db.SaveChanges();
        }
    }
}