﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity_OAPS.Model;

namespace Entity_OAPS.Controllers
{
    public class HospitalDetailController : Controller
    {
        Entity_OAPSEntities1 db = new Entity_OAPSEntities1();
        public ActionResult HospitalDetailIndex()
        {
            return View();
        }
        public void Insert(HospitalDetail obj)
        {
            db.HospitalDetails.Add(obj);
            db.SaveChanges();
        }
        public JsonResult DisplayCity()
        {
            var data = (from a in db.tblCities select a).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}