﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity_OAPS.Model;


namespace Entity_OAPS.Controllers
{
    public class LoginController : Controller
    {
        Entity_OAPSEntities1 db = new Entity_OAPSEntities1();
        public ActionResult LoginIndex()
        {
            return View();
        }
        public JsonResult LoginUser(tblRegistration obj)
        {
            var data = (from x in db.tblRegistrations where x.p_email == obj.p_email && x.password == obj.password select x).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}