﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity_OAPS.Model;

namespace Entity_OAPS.Controllers
{
    public class ShowRegController : Controller
    {
        Entity_OAPSEntities1 db = new Entity_OAPSEntities1();
        public ActionResult RegShowIndex(string QS)
        {
            ViewBag.data = QS;
            return View();
        }
        public JsonResult GetDataById(int A)
        {
            var data = (from x in db.tblRegistrations where x.p_id == A select x).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}