﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity_OAPS.Model;

namespace Entity_OAPS.Controllers
{
    public class AboutusController : Controller
    {
        Entity_OAPSEntities1 db = new Entity_OAPSEntities1();
        public ActionResult AboutusIndex()
        {
            return View();
        }
    }
}