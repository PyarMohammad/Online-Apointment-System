﻿function Clear() {
    $("#txtfname").val("");
    $("#txtlname").val("");
    $("#txtage").val("");
    $("input:radio").attr("checked", false);
    $("#txtaddress").val("");
    $("#txtphone").val("");
    $("#txtemail").val("");
    $("#txtdiagnosis").val("");
    $("#txtdtxtgroup").val("");
    $("#txtbed").val("");
    $("#txtdpt").val("");
    $("#txthospital").val("");
    $("#btnpatient").val("Patient");
}

function PatientDataData() {
    $.ajax({
        url: '../PatientDetail/Insert',
        data: { p_fname: $("#txtfname").val(), p_lname: $("#txtlname").val(), p_age: $("#txtage").val(), p_gender: $('input:radio[name=Gender]:checked').val(), p_address: $("#txtaddress").val(), p_phone: $("#txtphone").val(), p_email: $("#txtemail").val(), p_current_diagnosis: $("#txtdiagnosis").val(), p_blood_group: $("#txtgroup").val(), p_bed_no: $("#txtbed").val(), p_dept: $("#txtdpt").val(), p_hopital_name: $("#txthospital").val() },
        success: function () {
            alert("Patient Data successfull insert!");
            Clear();
        },
        error: function () {
            alert("Patient Data not insert");
        }
    });
}