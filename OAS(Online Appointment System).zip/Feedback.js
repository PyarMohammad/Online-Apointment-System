﻿

function Clear() {
    $("#txtname").val("");
    $("#txtcomments").val("");
    $("#btnfeedback").val("Feedback");
}

function Feedback() {
    $.ajax({
        url: '../Feedback/Insert',
        data: { name: $("#txtname").val(), comment: $("#txtcomments").val() },
        success: function () {
            alert("Feedback is successfull send !");
            Clear();
        },
        error: function () {
            alert("Feddback fail!!");
        }
    });
}

