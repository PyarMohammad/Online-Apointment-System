﻿

function Clear() {
    $("#txtfname").val("");
    $("#txtlname").val("");
    $("#txtage").val("");
    $("input:radio").attr("checked", false);
    $("#txtaddress").val("");
    $("#txtphone").val("");
    $("#txtemail").val("");
    $("#txtdiagnosis").val("");
    $("#txtpwd").val("");
    $("#txtconpwd").val("");
    $("#btnregistration").val("Registered");
}

function RagisterdData() {
    $.ajax({
        url: '../Reg/Insert',
        data: { p_fname: $("#txtfname").val(), p_lname: $("#txtlname").val(), p_age: $("#txtage").val(), p_gender: $('input:radio[name=Gender]:checked').val(), p_address: $("#txtaddress").val(), p_phone: $("#txtphone").val(), p_email: $("#txtemail").val(), p_current_diagnosis: $("#txtdiagnosis").val(), password: $("#txtpwd").val(), c_password: $("#txtconpwd").val() },
        success: function () {
            alert("Registration is successfull !");
            Clear();
        },
        error: function () {
            alert("Registration fail!!");
        }
    });
}


