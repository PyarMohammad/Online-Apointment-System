﻿function Login() {
    $.ajax({
        url: '../Login/LoginUser',
        data: { p_email: $("#txtemail").val(), password: $("#txtpassword").val() },
        success: function (data) {
            if (data.length > 0) {
                window.location.href = "../ShowReg/RegShowIndex?QS=" + data[0].p_id;
            }
        },
        error: function () {
            alert("Login  fail!");
        }
    });
}