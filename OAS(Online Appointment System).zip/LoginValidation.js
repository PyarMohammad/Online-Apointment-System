﻿function LValidation() {
    var Dabba = "";

    Dabba += checkemail();
    Dabba += checkpaw();

    if (Dabba != "") {
        alert(Dabba);
        return false;
    }
    else {
        Login();
    }
}


function checkemail() {
    var TB = $("#txtemail");
    var Exp = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
    if (TB.val() == "") {
        return 'Please enter your email\n'
    }
    else if (!Exp.test(TB.val())) {
        return "Please Enter valid email!!\n";
    }
    else {
        return "";
    }
}


function checkpaw() {
    var TB = $("#txtpassword");
    if (TB.val() == "") {
        return "Please enter your password\n";
    }
    else {
        return "";
    }
}